
import React from 'react';
import { BUSINESS_INFO } from '../constants';

export const Footer: React.FC = () => {
  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const targetId = id.toLowerCase().replace(/\s+/g, '-');
    const element = document.getElementById(targetId);
    
    if (id === 'Home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer className="bg-white pt-20 pb-10 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="bg-blue-600 p-2 rounded-lg">
                <i className="fas fa-city text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-slate-900">
                FAS <span className="text-blue-600">DEVELOPERS</span>
              </span>
            </div>
            <p className="text-slate-500 mb-8 leading-relaxed">
              Leading the way in premium property development and consultancy across Karachi. Your vision, our expertise.
            </p>
            <div className="flex gap-4">
              {['facebook', 'twitter', 'instagram', 'linkedin', 'whatsapp'].map(social => (
                <a 
                  key={social}
                  href="#" 
                  onClick={(e) => e.preventDefault()}
                  className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-blue-600 hover:text-white transition-all"
                >
                  <i className={`fab fa-${social}`}></i>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-slate-900 font-bold mb-6">Explore</h4>
            <ul className="space-y-4">
              {['Home', 'Properties', 'AI Advisor', 'About', 'Contact'].map(item => (
                <li key={item}>
                  <a 
                    href={`#${item.toLowerCase().replace(' ', '-')}`} 
                    onClick={(e) => handleScroll(e, item)}
                    className="text-slate-500 hover:text-blue-600 transition-colors"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-slate-900 font-bold mb-6">Property Types</h4>
            <ul className="space-y-4">
              {['Luxury Villas', 'Corporate Offices', 'Residential Plots', 'Retail Spaces', 'Apartments'].map(item => (
                <li key={item}>
                  <a href="#" onClick={(e) => e.preventDefault()} className="text-slate-500 hover:text-blue-600 transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-slate-900 font-bold mb-6">Office Hours</h4>
            <ul className="space-y-4 text-slate-500">
              <li className="flex justify-between">
                <span>Mon - Sat:</span>
                <span className="font-medium text-slate-700">10:00 - 20:00</span>
              </li>
              <li className="flex justify-between">
                <span>Sunday:</span>
                <span className="font-medium text-slate-700">Appointment Only</span>
              </li>
              <li className="pt-4 mt-4 border-t border-slate-100">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Location</p>
                <p className="text-slate-700 text-sm leading-relaxed">
                  {BUSINESS_INFO.address}
                </p>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-10 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-400">
          <p>© {new Date().getFullYear()} FAS Real Estate Developers. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-blue-600">Privacy Policy</a>
            <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-blue-600">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
