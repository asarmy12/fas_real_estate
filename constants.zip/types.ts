
export interface Property {
  id: string;
  title: string;
  location: string;
  price: string;
  beds: number;
  baths: number;
  area: string;
  image: string;
  type: 'Sale' | 'Rent';
  category: 'Residential' | 'Commercial' | 'Plot';
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  links?: Array<{ title: string; uri: string }>;
}
