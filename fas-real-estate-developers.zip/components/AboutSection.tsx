
import React from 'react';
import { BUSINESS_INFO } from '../constants';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 px-4 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2 relative">
            <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl">
              <img 
                src="https://picsum.photos/seed/realestate-office/800/800" 
                alt="FAS Real Estate Office"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-8 -right-8 bg-blue-600 text-white p-8 rounded-3xl shadow-xl z-20 hidden md:block">
              <div className="text-4xl font-bold mb-1">10+</div>
              <div className="text-sm font-medium text-blue-100 uppercase tracking-wider">Years of Excellence</div>
            </div>
            <div className="absolute -top-6 -left-6 w-32 h-32 bg-blue-50 rounded-full -z-0"></div>
          </div>
          
          <div className="lg:w-1/2">
            <h4 className="text-blue-600 font-bold tracking-widest uppercase text-sm mb-4">About Our Agency</h4>
            <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-8 leading-tight">
              A Legacy of Trust in Karachi's Real Estate
            </h2>
            <p className="text-slate-600 text-lg mb-6 leading-relaxed">
              FAS Real Estate Developers is a premier real estate agency and development firm based in the heart of Karachi. We specialize in identifying high-potential residential, commercial, and plot opportunities for our diverse clientele.
            </p>
            <p className="text-slate-600 text-lg mb-10 leading-relaxed">
              With a perfect 5.0-star rating from our valued clients, our commitment to transparency, legal integrity, and market expertise remains unmatched. Whether you are looking for a luxury home in DHA or a strategic plot in Bahria Town, we are your trusted partners.
            </p>
            
            <div className="grid grid-cols-2 gap-8 mb-10">
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                    <i className="fas fa-check-circle text-blue-600"></i>
                  </div>
                  <h5 className="font-bold text-slate-900">Legal Verification</h5>
                </div>
                <p className="text-sm text-slate-500">Every property we handle undergoes rigorous legal checks.</p>
              </div>
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                    <i className="fas fa-handshake text-blue-600"></i>
                  </div>
                  <h5 className="font-bold text-slate-900">Expert Consultancy</h5>
                </div>
                <p className="text-sm text-slate-500">Professional advice tailored to your investment goals.</p>
              </div>
            </div>
            
            <button className="bg-slate-900 text-white px-8 py-4 rounded-xl font-bold hover:bg-slate-800 transition-all shadow-lg active:scale-95">
              Learn More About Us
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
