
import React, { useState } from 'react';

interface HeroProps {
  onSearch: (query: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onSearch }) => {
  const [val, setVal] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(val);
    
    const element = document.getElementById('properties');
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="relative h-[85vh] flex items-center justify-center overflow-hidden">
      {/* Background with overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center" 
        style={{ backgroundImage: 'url("https://picsum.photos/seed/karachi/1920/1080")' }}
      >
        <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px]"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto text-center px-4">
        <h1 className="text-4xl md:text-6xl font-extrabold text-white mb-6 leading-tight">
          Find Your Dream Space in <span className="text-blue-400">Karachi</span>
        </h1>
        <p className="text-lg md:text-xl text-slate-200 mb-10 max-w-2xl mx-auto">
          FAS Real Estate Developers offers premier residential and commercial opportunities with 100% customer satisfaction.
        </p>

        <form 
          onSubmit={handleSubmit}
          className="bg-white p-2 rounded-2xl shadow-2xl flex flex-col md:flex-row gap-2 max-w-2xl mx-auto"
        >
          <div className="flex-1 relative">
            <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
            <input
              type="text"
              value={val}
              onChange={(e) => setVal(e.target.value)}
              placeholder="Search by area (DHA, Clifton, etc.)"
              className="w-full pl-12 pr-4 py-4 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
          <button 
            type="submit"
            className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
          >
            <span>Search</span>
            <i className="fas fa-arrow-right text-sm"></i>
          </button>
        </form>

        <div className="mt-12 flex flex-wrap justify-center gap-8 text-white">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
              <i className="fas fa-star text-yellow-400"></i>
            </div>
            <div className="text-left">
              <p className="font-bold text-lg">5.0 Rating</p>
              <p className="text-xs text-slate-300">17 Google Reviews</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
              <i className="fas fa-shield-alt text-blue-400"></i>
            </div>
            <div className="text-left">
              <p className="font-bold text-lg">Trusted Firm</p>
              <p className="text-xs text-slate-300">Registered Developers</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div 
        className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce text-white/50 cursor-pointer"
        onClick={() => {
           const element = document.getElementById('properties');
           if (element) window.scrollTo({ top: element.offsetTop - 80, behavior: 'smooth' });
        }}
      >
        <i className="fas fa-chevron-down text-2xl"></i>
      </div>
    </div>
  );
};
