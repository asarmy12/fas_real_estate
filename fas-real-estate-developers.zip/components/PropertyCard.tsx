
import React from 'react';
import { Property } from '../types';

interface PropertyCardProps {
  property: Property;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property }) => {
  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-200 hover:shadow-xl transition-all duration-300 group">
      <div className="relative h-64 overflow-hidden">
        <img 
          src={property.image} 
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4 flex gap-2">
          <span className="bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase">
            For {property.type}
          </span>
          <span className="bg-white/90 backdrop-blur-sm text-slate-900 text-xs font-bold px-3 py-1 rounded-full uppercase">
            {property.category}
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold text-slate-900 mb-2 line-clamp-1">{property.title}</h3>
        <p className="text-slate-500 flex items-center gap-2 mb-4">
          <i className="fas fa-map-marker-alt text-blue-500 text-sm"></i>
          {property.location}
        </p>
        
        <div className="flex items-center justify-between py-4 border-t border-slate-100">
          <div className="flex gap-4">
            {property.beds > 0 && (
              <div className="flex items-center gap-1.5 text-slate-600 text-sm">
                <i className="fas fa-bed"></i>
                <span>{property.beds}</span>
              </div>
            )}
            {property.baths > 0 && (
              <div className="flex items-center gap-1.5 text-slate-600 text-sm">
                <i className="fas fa-bath"></i>
                <span>{property.baths}</span>
              </div>
            )}
            <div className="flex items-center gap-1.5 text-slate-600 text-sm">
              <i className="fas fa-vector-square"></i>
              <span>{property.area}</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-4">
          <p className="text-xl font-bold text-blue-600">{property.price}</p>
          <button className="p-2.5 rounded-xl border border-blue-100 text-blue-600 hover:bg-blue-600 hover:text-white transition-colors">
            <i className="fas fa-external-link-alt"></i>
          </button>
        </div>
      </div>
    </div>
  );
};
