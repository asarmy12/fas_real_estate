
import React from 'react';
import { PropertyCard } from './PropertyCard';
import { Property } from '../types';

interface PropertyGridProps {
  properties: Property[];
}

export const PropertyGrid: React.FC<PropertyGridProps> = ({ properties }) => {
  if (properties.length === 0) {
    return (
      <div className="text-center py-20 bg-slate-100 rounded-3xl border-2 border-dashed border-slate-300">
        <div className="bg-slate-200 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="fas fa-search text-slate-400 text-2xl"></i>
        </div>
        <h3 className="text-xl font-semibold text-slate-700">No properties found</h3>
        <p className="text-slate-500">Try adjusting your filters or search terms.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {properties.map((property) => (
        <PropertyCard key={property.id} property={property} />
      ))}
    </div>
  );
};
