
import { Property } from './types';

export const BUSINESS_INFO = {
  name: "FAS Real Estate Developers",
  address: "Plot 352, D Area, Qayyumabad, Karachi, 75640",
  phone: "+92 345 2334075",
  email: "info@fasdevelopers.com",
  rating: 5.0,
  reviews: 17
};

export const FEATURED_PROPERTIES: Property[] = [
  {
    id: '1',
    title: 'Luxury 4-Bed Villa in DHA Phase 8',
    location: 'DHA Phase 8, Karachi',
    price: 'PKR 14.5 Crore',
    beds: 4,
    baths: 5,
    area: '500 Sq. Yds',
    image: 'https://picsum.photos/seed/dha8/800/600',
    type: 'Sale',
    category: 'Residential'
  },
  {
    id: '2',
    title: 'Modern Corporate Office Space',
    location: 'Clifton Block 4, Karachi',
    price: 'PKR 4.2 Crore',
    beds: 0,
    baths: 2,
    area: '2000 Sq. Ft',
    image: 'https://picsum.photos/seed/clifton/800/600',
    type: 'Sale',
    category: 'Commercial'
  },
  {
    id: '3',
    title: 'Executive Apartment with Sea View',
    location: 'Emaar Oceanfront, Karachi',
    price: 'PKR 1.25 Lakh / month',
    beds: 3,
    baths: 3,
    area: '2400 Sq. Ft',
    image: 'https://picsum.photos/seed/emaar/800/600',
    type: 'Rent',
    category: 'Residential'
  },
  {
    id: '4',
    title: 'Residential Plot in Bahria Town',
    location: 'Precinct 1, Bahria Town Karachi',
    price: 'PKR 2.8 Crore',
    beds: 0,
    baths: 0,
    area: '250 Sq. Yds',
    image: 'https://picsum.photos/seed/bahria/800/600',
    type: 'Sale',
    category: 'Plot'
  }
];
