
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { PropertyGrid } from './components/PropertyGrid';
import { AIAdvisor } from './components/AIAdvisor';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FEATURED_PROPERTIES } from './constants';

const App: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'All' | 'Residential' | 'Commercial' | 'Plot'>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProperties = FEATURED_PROPERTIES.filter(p => {
    const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar />
      
      <main>
        <Hero 
          onSearch={(query) => setSearchQuery(query)} 
        />
        
        <section id="properties" className="py-20 px-4 max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Featured Properties</h2>
              <p className="text-slate-600 max-w-xl">
                Explore our curated selection of premium properties across Karachi's most sought-after neighborhoods.
              </p>
            </div>
            
            <div className="flex flex-wrap gap-2">
              {['All', 'Residential', 'Commercial', 'Plot'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat as any)}
                  className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
                    activeCategory === cat 
                    ? 'bg-blue-600 text-white shadow-md' 
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
          
          <PropertyGrid properties={filteredProperties} />
        </section>

        <section id="ai-advisor" className="bg-slate-900 py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <AIAdvisor />
          </div>
        </section>

        <AboutSection />
        
        <ContactSection />
      </main>

      <Footer />
    </div>
  );
};

export default App;
