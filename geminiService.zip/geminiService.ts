
import { GoogleGenAI } from "@google/genai";
import { BUSINESS_INFO } from "./constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getRealEstateAdvice(prompt: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: `You are a professional real estate advisor for "FAS Real Estate Developers" based in Karachi, Pakistan. 
        Your tone is professional, helpful, and knowledgeable about the Karachi property market (DHA, Clifton, Bahria Town, Qayyumabad, North Nazimabad, etc.). 
        Reference the business info if relevant: Address: ${BUSINESS_INFO.address}, Phone: ${BUSINESS_INFO.phone}.
        If the user asks about market trends or specific prices, use the Google Search tool to provide accurate information.`,
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "I'm sorry, I couldn't process that request right now.";
    const links = response.candidates?.[0]?.groundingMetadata?.groundingChunks
      ?.map((chunk: any) => chunk.web)
      .filter(Boolean) || [];

    return { text, links };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { text: "Error connecting to AI advisor. Please try again later.", links: [] };
  }
}
